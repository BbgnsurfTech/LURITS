<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsTeachingQualification extends Model
{
    public $table = 'ds_teaching_qualification';
}
