<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsTeachingTypePartTime extends Model
{
    //
}
