<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsClassSector extends Model
{
    public $table = 'ds_class_sector';
}
