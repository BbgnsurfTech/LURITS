<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsPresentStatus extends Model
{
    public $table = 'ds_present_status';
}
