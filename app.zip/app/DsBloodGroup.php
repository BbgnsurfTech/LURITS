<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsBloodGroup extends Model
{
    public $table = 'ds_blood_group';
}
