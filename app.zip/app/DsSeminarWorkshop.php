<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsSeminarWorkshop extends Model
{
    public $table = 'ds_seminar_workshop';
}
