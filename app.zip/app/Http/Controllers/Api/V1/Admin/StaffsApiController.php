<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTeacherRequest;
use App\Http\Requests\UpdateTeacherRequest;
use App\Http\Resources\Admin\TeacherResource;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Traits\CsvImportTrait;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use Spatie\MediaLibrary\Models\Media;
use App\Http\Requests\MassDestroyStaffRequest;
use App\Http\Requests\StoreStaffRequest;
use App\Http\Requests\UpdateStaffRequest;
use Validator;
use Storage;
use App\SchoolAtlas;
use App\Staff;
use App\Term;
use App\AtlasLink;
use App\Session;
use App\DsPresentStatus;
use App\DsTeachingTypePartTime;
use App\DsSalarySource;
use App\DsGender;
use App\DsAcademicQualification;
use App\DsTeachingType;
use App\DsTypeStaff;
use App\DsSector;
use App\DsMaritalStatus;
use App\DsTeachingQualification;
use App\DsSeminarWorkshop;
use App\DsDisability;
use App\Subject;
use App\School;
use App\Atlas;
use App\User;
use Illuminate\Support\Collection;
use Yajra\DataTables\Facades\DataTables;
use Auth;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Haruncpi\LaravelIdGenerator\IdGenerator;

class StaffsApiController extends Controller
{
    public function index(Request $request)
    {
        // abort_if(Gate::denies('staff_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        // return new TeacherResource(Teacher::with(['school'])->get());

        $data = Staff::where("school_id", $request->school)->with(["teaching_type_part_time", "type_staff", "maritalstatus", "disability", "salary_source", "present_status", "academic_qualification", "teaching_qualification", "subject_of_qualification", "subject_taught", "area_of_specialization", "teaching_type", "seminar_workshop", "school", "gender", "state_origin", "lga_origin", "rank"])->get();
        return response($data);
    }

    public function store(Request $request)
    {
        $data = $request->all();
        return response($data);
        // $term_id = Term::where('active_status', 1)->select('id')->get();
        // $session_id = Session::where('active_status', 1)->select('id')->get();

        // if ($request->state_origin == null || $request->lga_origin == null) {
        //     return response([
        //         'success' => false,
        //         'message' => "The State and LGA of Origin fields are required.",
        //     ], 200);
        // }

        // $state = Atlas::where('name_atlas_entity', $request->state_origin)->first();
        // $lga = Atlas::where('name_atlas_entity', $request->lga_origin)->first();

        // if ($state == null || $lga == null) {
        //     return response([
        //         'success' => false,
        //         'message' => "The State or LGA of Origin is not found.",
        //     ], 200);
        // }

        // $r = School::find($request->school_id)->lga->code_atlas_entity;
        // $rr = $session_id[0]->id;
        // $s = Staff::max('id') +1;
        // $u = str_pad($r.$rr, 12, '0', STR_PAD_RIGHT) +$s;

        // DB::beginTransaction();
        // try {
            
        //     // if ($request->staff_picture !== null) {
        //     //     // Start Api Create 

        //     //     $curl = curl_init();

        //     //     curl_setopt_array($curl, array(
        //     //         CURLOPT_URL => "https://api.luxand.cloud/subject",
        //     //         CURLOPT_RETURNTRANSFER => true,
        //     //         CURLOPT_ENCODING => "",
        //     //         CURLOPT_MAXREDIRS => 10,
        //     //         CURLOPT_TIMEOUT => 30,
        //     //         CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        //     //         CURLOPT_CUSTOMREQUEST => "POST",
        //     //         CURLOPT_POSTFIELDS => [ "name" => $name], 
        //     //         CURLOPT_HTTPHEADER => array(
        //     //             "token: 631dc0a781be4335997fb893b1d3de55"
        //     //         ),
        //     //     ));

        //     //     $response = curl_exec($curl);
        //     //     $err = curl_error($curl);

        //     //     curl_close($curl);

        //     //     if ($err) {
        //     //         session()->flash('error', 'Something went wrong while registering user api ID');
        //     //         return redirect()->back();
        //     //     } else {
        //     //         $data = json_decode($response);
        //     //         $api_id = $data->id;
        //     //     }

        //     //     // End Api Create
                
        //     //     // Start Api Face

        //     //     $curl = curl_init();
        //     //     $link = "https://api.luxand.cloud/subject/".$api_id;
        //     //     curl_setopt_array($curl, array(
        //     //         CURLOPT_URL => $link,
        //     //         CURLOPT_RETURNTRANSFER => true,
        //     //         CURLOPT_ENCODING => "",
        //     //         CURLOPT_MAXREDIRS => 10,
        //     //         CURLOPT_TIMEOUT => 30,
        //     //         CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        //     //         CURLOPT_CUSTOMREQUEST => "POST",
        //     //         //CURLOPT_POSTFIELDS => [ "store" => "1", "photo" => curl_file_create($b)], 
        //     //         // or use URL
        //     //         CURLOPT_POSTFIELDS => [ "photo" => $b ], 
        //     //         CURLOPT_HTTPHEADER => array(
        //     //             "token: 631dc0a781be4335997fb893b1d3de55"
        //     //         ),
        //     //     ));

        //     //     $response = curl_exec($curl);
        //     //     $errr = curl_error($curl);

        //     //     curl_close($curl);

        //     //     if ($errr) {
        //     //         dd($errr);
        //     //         session()->flash('error', 'Something went wrong while registering user api FACE');
        //     //         return redirect()->back();
        //     //     } else {
        //     //         $res = json_decode($response);
        //     //     }

        //     //     // End Api Face
        //     // }

        //     $user = new User();
        //     $user->name = $request->first_name. ' ' .$request->middle_name. ' ' .$request->last_name;
        //     if ($request->email !== null) {
        //         $user->email = $request->email;
        //     } else {
        //         $user->username = 'custom_username';
        //     }
        //     $user->password = Hash::make(12345678);
        //     $user->school_id = $request->school;
        //     $user->save();
        //     $user->toArray();

        //     $data = new Staff();
        //     // if ($request->staff_picture !== null) {
        //     //     $data->api_id = $api_id;
        //     // }
        //     $data->staff_id = $u;
        //     $data->first_name = $request->first_name;
        //     $data->middle_name = $request->middle_name;
        //     $data->last_name = $request->last_name;
        //     // $data->email = $request->email;
        //     // $data->phone_number = $request->phone_number;
        //     $data->email = $request->email;
        //     $data->phone_number = $request->phone_number;
        //     $data->date_of_birth = $request->date_of_birth;
        //     $data->state_of_origin_id = $state->code_atlas_entity;
        //     $data->lga_of_origin_id = $lga->code_atlas_entity;
        //     $data->marital_status_id = $request->marital_status;
        //     $data->disability = $request->disability;
        //     $data->grade_step = $request->grade_step;
        //     $data->gender_id = $request->gender;
        //     $data->type_staff_id = $request->type_staff_id;
        //     $data->present_status_id = $request->present_status_id;
        //     $data->academic_qualification_id = $request->academic_qualification_id;
        //     $data->teaching_type_id = $request->teaching_type_id;
        //     $data->salary_source_id = $request->salary_source_id;
        //     $data->year_first_appointment = $request->year_first_appointment;
        //     $data->year_present_appointment = $request->year_present_appointment;
        //     $data->year_posting_to_school = $request->year_posting_to_school;
        //     $data->teaching_type_part_time = $request->teaching_type_part_time;
        //     $data->term_id = $term_id[0]->id;
        //     $data->session_id = $session_id[0]->id;
        //     $data->school_id = $request->school_id;
        //     $data->teaching_qualification_id = $request->teaching_qualification;
        //     $data->area_of_specialization_id = $request->area_of_specialization;
        //     $data->subject_of_qualification_id = $request->subject_of_qualification;
        //     $data->main_subject_taught_id = $request->subject_taught;
        //     $data->seminar_workshop_id = $request->seminar_workshop;

        //     $results = $data->save();

        //     // if ($request->input('staff_picture', false)) {
        //     //     $data->addMedia(storage_path('app/public/files/' . $request->input('staff_picture')))->toMediaCollection('staff_picture');
        //     // }

        //     // foreach ($request->input('staff_document', []) as $file) {
        //     //     $data->addMedia(storage_path('app/public/files/' . $file))->toMediaCollection('staff_document');
        //     // }

        //     // if ($media = $request->input('ck-media', false)) {
        //     //     Media::whereIn('id', $media)->update(['model_id' => $data->id]);
        //     // }

            

        //     DB::commit();

        // } catch (\Exception $e) {
        //     //dd($e);
        //     DB::rollback();
        //     return response([
        //         'success' => false,
        //         'message' => "Operation Failed, Server Error!",
        //         'error' => $e,
        //     ], 200);
        // }

        // if ($results) {
        //     return response([
        //         'success' => true,
        //         'message' => "Staff Data Added Successfully",
        //     ], 200);
        // }

        // if ($request->staff_picture !== null) {
        //     $name = $request->first_name. ' ' .$request->last_name;
        //     $image = 'files/'.$request->input('staff_picture');
        //     $file = Storage::url($image);
        //     $url = config("app.url");
        //     $b = asset($url.'/'.$image);

        //     $imagee = base64_encode($b);
        //     dd($imagee);
        // }

        // $term_id = Term::where('active_status', 1)->select('id')->get();
        // $session_id = Session::where('active_status', 1)->select('id')->get();
        
        // if ($request->academic_qualification !== "1") {
        //     $request->validate([
        //         'teaching_qualification' => "required",
        //         'area_of_specialization' => "required",
        //         'subject_of_qualification' => "required",
        //         'subject_taught' => "required",
        //         'seminar_workshop' => "required",
        //         'teaching_sector' => "required",
        //     ]);
        // }

        // if ($request->lga_origin == 0 || $request->school == 0) {
        //     session()->flash('error', 'Operation Failed. You didn\'t select LGA of Origin or School');
        //     return redirect()->back();
        // }

        // if ($request->disability == 1 && $request->disability_text == null) {
        //     session()->flash('error', 'Operation Failed. You selected YES for staff disablity, but didn\'t specify the staff\'s disability');
        //     return redirect()->back();
        // }

        // if ($request->teaching_type == 2 && $request->teaching_type_part_time == null) {
        //     session()->flash('error', 'Operation Failed. You selected PART TIME for staff teaching type, but didn\'t specify the staff\'s teaching type');
        //     return redirect()->back();
        // }

        // $r = School::find($request->school)->lga->code_atlas_entity;
        // $rr = $session_id[0]->id;
        // $s = Staff::max('id') +1;
        // $u = str_pad($r.$rr, 12, '0', STR_PAD_RIGHT) +$s;
        
        // DB::beginTransaction();
        // try {
            
        //     if ($request->staff_picture !== null) {
        //         // Start Api Create 

        //         $curl = curl_init();

        //         curl_setopt_array($curl, array(
        //             CURLOPT_URL => "https://api.luxand.cloud/subject",
        //             CURLOPT_RETURNTRANSFER => true,
        //             CURLOPT_ENCODING => "",
        //             CURLOPT_MAXREDIRS => 10,
        //             CURLOPT_TIMEOUT => 30,
        //             CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        //             CURLOPT_CUSTOMREQUEST => "POST",
        //             CURLOPT_POSTFIELDS => [ "name" => $name], 
        //             CURLOPT_HTTPHEADER => array(
        //                 "token: 631dc0a781be4335997fb893b1d3de55"
        //             ),
        //         ));

        //         $response = curl_exec($curl);
        //         $err = curl_error($curl);

        //         curl_close($curl);

        //         if ($err) {
        //             session()->flash('error', 'Something went wrong while registering user api ID');
        //             return redirect()->back();
        //         } else {
        //             $data = json_decode($response);
        //             $api_id = $data->id;
        //         }

        //         // End Api Create
                
        //         // Start Api Face

        //         $curl = curl_init();
        //         $link = "https://api.luxand.cloud/subject/".$api_id;
        //         curl_setopt_array($curl, array(
        //             CURLOPT_URL => $link,
        //             CURLOPT_RETURNTRANSFER => true,
        //             CURLOPT_ENCODING => "",
        //             CURLOPT_MAXREDIRS => 10,
        //             CURLOPT_TIMEOUT => 30,
        //             CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        //             CURLOPT_CUSTOMREQUEST => "POST",
        //             //CURLOPT_POSTFIELDS => [ "store" => "1", "photo" => curl_file_create($b)], 
        //             // or use URL
        //             CURLOPT_POSTFIELDS => [ "photo" => $b ], 
        //             CURLOPT_HTTPHEADER => array(
        //                 "token: 631dc0a781be4335997fb893b1d3de55"
        //             ),
        //         ));

        //         $response = curl_exec($curl);
        //         $errr = curl_error($curl);

        //         curl_close($curl);

        //         if ($errr) {
        //             dd($errr);
        //             session()->flash('error', 'Something went wrong while registering user api FACE');
        //             return redirect()->back();
        //         } else {
        //             $res = json_decode($response);
        //         }

        //         // End Api Face
        //     }

        //     $user = new User();
        //     $user->name = $request->first_name. ' ' .$request->middle_name. ' ' .$request->last_name;
        //     if ($request->email !== null) {
        //         $user->email = $request->email;
        //     } else {
        //         $user->username = 'custom_username';
        //     }
        //     $user->password = Hash::make(12345678);
        //     $user->school_id = $request->school;
        //     $user->save();
        //     $user->toArray();

        //     $data = new Staff();
        //     if ($request->staff_picture !== null) {
        //         $data->api_id = $api_id;
        //     }
        //     $data->staff_id = $u;
        //     $data->first_name = $request->first_name;
        //     $data->middle_name = $request->middle_name;
        //     $data->last_name = $request->last_name;
        //     $data->email = $request->email;
        //     $data->phone_number = $request->phone_number;
        //     $data->date_of_birth = $request->date_of_birth;
        //     $data->state_of_origin_id = $request->state_origin;
        //     $data->lga_of_origin_id = $request->lga_origin;
        //     $data->marital_status_id = $request->marital_status;
        //     $data->disability_text = $request->disability_text;
        //     $data->disability_id = $request->disability;
        //     $data->grade_step = $request->grade_step;
        //     $data->gender_id = $request->gender;
        //     $data->type_staff_id = $request->type_of_staff;
        //     $data->present_status_id = $request->present;
        //     $data->academic_qualification_id = $request->academic_qualification;
        //     $data->teaching_type_id = $request->teaching_type;
        //     $data->salary_source_id = $request->source_of_salary;
        //     $data->year_first_appointment = $request->first_appointment;
        //     $data->year_present_appointment = $request->present_appointment;
        //     $data->year_posting_to_school = $request->posting_to_school;
        //     $data->teaching_type_part_time = $request->teaching_type_part_time;
        //     $data->term_id = $term_id[0]->id;
        //     $data->session_id = $session_id[0]->id;
        //     $data->school_id = $request->school;
        //     if ($request->academic_qualification !== "1") {
        //     $data->sector_id = $request->teaching_sector;
        //     $data->teaching_qualification_id = $request->teaching_qualification;
        //     $data->area_of_specialization_id = $request->area_of_specialization;
        //     $data->subject_of_qualification_id = $request->subject_of_qualification;
        //     $data->main_subject_taught_id = $request->subject_taught;
        //     $data->seminar_workshop_id = $request->seminar_workshop;
        //     }
        //     //dd($data);
        //     $results = $data->save();

        //     if ($request->input('staff_picture', false)) {
        //         $data->addMedia(storage_path('app/public/files/' . $request->input('staff_picture')))->toMediaCollection('staff_picture');
        //     }

        //     foreach ($request->input('staff_document', []) as $file) {
        //         $data->addMedia(storage_path('app/public/files/' . $file))->toMediaCollection('staff_document');
        //     }

        //     if ($media = $request->input('ck-media', false)) {
        //         Media::whereIn('id', $media)->update(['model_id' => $data->id]);
        //     }

            

        //     DB::commit();

        // } catch (\Exception $e) {
        //     dd($e);
        //     DB::rollback();
        //     session()->flash('error', 'Operation Failed');
        //     return redirect()->back();
        // }

        // if ($results) {
        //     session()->flash('message', 'Staff Data Added Successfully');
        //     return redirect()->route('admin.staffs.index');
        // }        

        // return redirect()->route('admin.staffs.index');
    }

    public function show(Teacher $teacher)
    {
        abort_if(Gate::denies('staff_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new TeacherResource($teacher->load(['school']));
    }

    public function update(UpdateTeacherRequest $request, Teacher $teacher)
    {
        $teacher->update($request->all());

        return (new TeacherResource($teacher))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Staff $staff)
    {
        abort_if(Gate::denies('staff_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $staff->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
