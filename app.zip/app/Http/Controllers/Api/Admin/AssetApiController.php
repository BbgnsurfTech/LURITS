<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Asset;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\StoreAssetRequest;
use App\Http\Requests\UpdateAssetRequest;
use App\Http\Resources\Admin\AssetResource;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Term;
use App\Session;
use Auth;

class AssetApiController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        if (Auth::User()->is_superAdmin || Auth::User()->is_admin) {
            $data = Asset::with(["staff", "category", "status", "school", "assigned_to"])->get();
        } elseif (Auth::User()->is_zeqa) {
            $zoneLGA = AtlasLink::where('code_atlas_link', $request->zone)->pluck('code_atlas_entity');
            $schools = SchoolAtlas::whereIn('code_atlas_entity', $lga)->pluck('school_id');
            $data = Asset::whereIn('school_id', $schools)->with(["staff", "category", "status", "school", "assigned_to"])->get();
        } elseif (Auth::User()->is_lgea) {
            $schools = SchoolAtlas::where('code_atlas_entity', $request->lga)->pluck('school_id');
            $data = Asset::whereIn('school_id', $schools)->with(["staff", "category", "status", "school", "assigned_to"])->get();

            $schoolLGA = SchoolAtlas::where('code_atlas_entity', $request->lga_id)->pluck('school_id');
            $schools = School::whereIn('id', $schoolLGA)->pluck('name','id');
            $data = Asset::with(["staff", "category", "status", "school", "assigned_to"])->get();
        } elseif (Auth::User()->is_headTeacher) {
            $data = Asset::where('school_id', Auth::User()->school_id)->with(["staff", "category", "status", "school", "assigned_to"])->get();   
        }
        
        return response($data);
    }

    public function store(StoreAssetRequest $request)
    {   
        $term_id = Term::where('active_status', 1)->select('id')->get();
        $session_id = Session::where('active_status', 1)->select('id')->get();
        
        $data = new Asset();
        $data->serial_number = $request->serial_number;
        $data->category_id = $request->category_id;
        $data->name = $request->name;
        $data->status_id = $request->status_id;
        $data->notes = $request->notes;
        $data->assigned_to_id = $request->assigned_to_id;
        $data->term_id = $term_id[0]->id;
        $data->session_id = $session_id[0]->id;
        $data->school_id = $request->school_id; 
        $final = $data->save();

        if ($request->input('photos', false)) {
            $asset->addMedia(storage_path('tmp/uploads/' . $request->input('photos')))->toMediaCollection('photos');
        }

        if ($final) {
            return response([
                'success' => true,
                'message' => "Asset Data Added Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }

        // $asset = Asset::create($request->all());

        // return (new AssetResource($asset))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(Asset $asset)
    {
        abort_if(Gate::denies('asset_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new AssetResource($asset->load(['category', 'status', 'location', 'assigned_to', 'school']));
    }

    public function update(UpdateAssetRequest $request, Asset $asset)
    {
        $asset->update($request->all());
        // $data = new Asset();
        // $data = Asset::find($asset->id)->firstOrFail();
        // $data->serial_number = $request->serial_number;
        // $data->category_id = $request->category_id;
        // $data->name = $request->name;
        // $data->status_id = $request->status_id;
        // $data->notes = $request->notes;
        // $data->assigned_to_id = $request->assigned_to_id;
        // $data->school_id = $request->school_id; 
        // $final = $data->update();

        // if ($request->input('photos', false)) {
        //     if (!$data->photos || $request->input('photos') !== $data->photos->file_name) {
        //         $data->addMedia(storage_path('tmp/uploads/' . $request->input('photos')))->toMediaCollection('photos');
        //     }
        // } elseif ($data->photos) {
        //     $data->photos->delete();
        // }

        if ($asset) {
            return response([
                'success' => true,
                'message' => "Asset Data Updated Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }

        // return (new AssetResource($asset))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Asset $asset)
    {
        abort_if(Gate::denies('asset_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $asset->delete();

        if ($asset) {
            return response([
                'success' => true,
                'message' => "Asset Deleted Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }
    }
}
