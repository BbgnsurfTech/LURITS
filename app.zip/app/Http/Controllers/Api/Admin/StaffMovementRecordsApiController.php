<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Smr;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\StoreSmrRequest;
use App\Http\Requests\UpdateSmrRequest;
use App\Http\Resources\Admin\SmrResource;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Session;
use App\Term;
use Validator;

class StaffMovementRecordsApiController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        $data = Smr::with(["staff"])->get();
        return response(
            json_decode($data),
        200);
        // abort_if(Gate::denies('smr_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        // return new SmrResource(Smr::with(['staff'])->get());
    }

    public function store(Request $request)
    {
        $request->validate([
            'date' => "required",
            'staff_id' => "required",
            'time_out' => "required",
            'time_back' => "required",
        ]);

        $term_id = Term::where('active_status', 1)->select('id')->get();
        $session_id = Session::where('active_status', 1)->select('id')->get();
        
        $data = new Smr();
        $data->date = $request->date;
        $data->staff_id = $request->staff_id;
        $data->contact_number = $request->contact_number;
        $data->purpose = $request->purpose;
        $data->time_out = $request->time_out;
        $data->time_back = $request->time_back;
        $data->ht_approval = $request->ht_approval;
        $data->school_id = $request->school_id;
        $data->term_id = $term_id[0]->id;
        $data->session_id = $session_id[0]->id;
        $final = $data->save();

        if ($final) {
            return response([
                'success' => true,
                'message' => "Staff Data Added Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }


        // $assmrset = Smr::create($request->all());

        // if ($request->input('photos', false)) {
        //     $smr->addMedia(storage_path('tmp/uploads/' . $request->input('photos')))->toMediaCollection('photos');
        // }

        // return (new SmrResource($smr))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(Smr $smr)
    {
        abort_if(Gate::denies('smr_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new SmrResource($smr->load(['category', 'status', 'location', 'assigned_to', 'school']));
    }

    public function update(UpdateSmrRequest $request, Smr $smr)
    {
        $smr->update($request->all());

        if ($smr) {
            return response([
                'success' => true,
                'message' => "Data Updated Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }

        // if ($request->input('photos', false)) {
        //     if (!$smr->photos || $request->input('photos') !== $smr->photos->file_name) {
        //         $smr->addMedia(storage_path('tmp/uploads/' . $request->input('photos')))->toMediaCollection('photos');
        //     }
        // } elseif ($smr->photos) {
        //     $smr->photos->delete();
        // }

        // return (new SmrResource($smr))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Smr $smr)
    {
        // abort_if(Gate::denies('smr_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $smr->delete();

        if ($smr) {
            return response([
                'success' => true,
                'message' => "Data Deleted Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }
    }
}
