<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\DsClass;
use App\Atlas;
use App\AtlasLink;
use App\SchoolAtlas;
use App\StudentAdmission;
use App\SchoolClass;

class ReportsController extends Controller
{
    public function index()
    {
        return view('admin.reports.index');
    }


    public function generate(Request $request)
    {
        // dd($request->all());
        $report = $request->report;
        if ($request->school > '0'  && $report == 'school1') {
            return ("not available");
        } else {
            $zoneReport = false;
            $lgaReport = false;
            $sectorReport = false;
            $schoolReport = false;

            if ($request->lga == null && $request->school_sector == null && $request->school <= '0') {
                // return("zone report");
                $zoneReport = true;
            } elseif ($request->school_sector == null && $request->school <= '0') {
                // return("lga report");
                $lgaReport = true;
            } elseif ($request->school <= "0") {
                // return("sector report");
                $sectorReport = true;
            } elseif ($request->school > '0') {
                // return("school report");
                $schoolReport = true;
            }

            if ($zoneReport) {
                //Enrolment Report
                $allClasses = DsClass::all();
                $zoneName = Atlas::where('code_atlas_entity', $request->zone)->first();
                //Get schools under the zone
                $lgas =  AtlasLink::where('code_atlas_link', $request->zone)->pluck('code_atlas_entity');
                $schoolLGAS = SchoolAtlas::whereIn('code_atlas_entity', $lgas)->pluck('school_id');
                //Get the students of this school
                $maleStudents = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->where('gender_id', 1)->count();
                $femaleStudents = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->where('gender_id', 2)->count();
                $classes = SchoolClass::whereIn('school_id', $schoolLGAS)->get();
                $primary1 = $classes->where('ds_class_id', 1)->pluck('id');
                $primary2 = $classes->where('ds_class_id', 2)->pluck('id');
                $primary3 = $classes->where('ds_class_id', 3)->pluck('id');
                $primary4 = $classes->where('ds_class_id', 4)->pluck('id');
                $primary5 = $classes->where('ds_class_id', 5)->pluck('id');
                $primary6 = $classes->where('ds_class_id', 6)->pluck('id');
                $js1 = $classes->where('ds_class_id', 7)->pluck('id');
                $js2 = $classes->where('ds_class_id', 8)->pluck('id');
                $js3 = $classes->where('ds_class_id', 9)->pluck('id');
                $ss1 = $classes->where('ds_class_id', 10)->pluck('id');
                $ss2 = $classes->where('ds_class_id', 11)->pluck('id');
                $ss3 = $classes->where('ds_class_id', 12)->pluck('id');
                $primary1StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary1)->where('gender_id', 1)->count();
                $primary1StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary1)->where('gender_id', 2)->count();
                $primary2StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary2)->where('gender_id', 1)->count();
                $primary2StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary2)->where('gender_id', 2)->count();
                $primary3StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary3)->where('gender_id', 1)->count();
                $primary3StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary3)->where('gender_id', 2)->count();
                $primary4StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary4)->where('gender_id', 1)->count();
                $primary4StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary4)->where('gender_id', 2)->count();
                $primary5StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary5)->where('gender_id', 1)->count();
                $primary5StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary5)->where('gender_id', 2)->count();
                $primary6StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary6)->where('gender_id', 1)->count();
                $primary6StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $primary6)->where('gender_id', 2)->count();
                $js1StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $js1)->where('gender_id', 1)->count();
                $js1StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $js1)->where('gender_id', 2)->count();
                $js2StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $js2)->where('gender_id', 1)->count();
                $js2StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $js2)->where('gender_id', 2)->count();
                $js3StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $js3)->where('gender_id', 1)->count();
                $js3StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $js3)->where('gender_id', 2)->count();
                $ss1StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $ss1)->where('gender_id', 1)->count();
                $ss1StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $ss1)->where('gender_id', 2)->count();
                $ss2StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $ss2)->where('gender_id', 1)->count();
                $ss2StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $ss2)->where('gender_id', 2)->count();
                $ss3StudentsMale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $ss3)->where('gender_id', 1)->count();
                $ss3StudentsFemale = StudentAdmission::whereIn('school_enrolled_id', $schoolLGAS)->whereIn('class_id', $ss3)->where('gender_id', 2)->count();
                
                return view('admin.reports.report-page', compact('zoneReport', 'lgaReport', 'sectorReport', 'schoolReport', 'report', 'allClasses', 'zoneName', 'maleStudents', 'femaleStudents', 'primary1StudentsMale', 'primary1StudentsFemale', 'primary2StudentsMale', 'primary2StudentsFemale', 'primary3StudentsMale', 'primary3StudentsFemale', 'primary4StudentsMale', 'primary4StudentsFemale', 'primary5StudentsMale', 'primary5StudentsFemale', 'primary6StudentsMale', 'primary6StudentsFemale', 'js1StudentsMale', 'js1StudentsFemale', 'js2StudentsMale', 'js2StudentsFemale', 'js3StudentsMale', 'js3StudentsFemale', 'ss1StudentsMale', 'ss1StudentsFemale', 'ss2StudentsMale', 'ss2StudentsFemale', 'ss3StudentsMale', 'ss3StudentsFemale'));
            }

            // dd($zoneReport, $lgaReport, $sectorReport, $schoolReport); 
        }
    }
}
