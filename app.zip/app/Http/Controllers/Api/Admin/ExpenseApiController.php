<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Expense;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreExpenseRequest;
use App\Http\Requests\UpdateExpenseRequest;
use App\Http\Resources\Admin\ExpenseResource;
use Gate;
use App\Term;
use App\Session;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ExpenseApiController extends Controller
{
    public function index()
    {
        // abort_if(Gate::denies('expense_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        // return new ExpenseResource(Expense::with(['expense_category', 'school'])->get());

        $data = Expense::with(["expense_category", "school"])->get();
        return response(
            json_decode($data),
        200);
    }

    public function store(StoreExpenseRequest $request)
    {
        // $expense = Expense::create($request->all());

        $term_id = Term::where('active_status', 1)->select('id')->get();
        $session_id = Session::where('active_status', 1)->select('id')->get();

        $data = new Expense();
        $data->entry_date = $request->entry_date;
        $data->amount = $request->amount;
        $data->description = $request->description;
        $data->beneficiary = $request->beneficiary;
        $data->issued_cheque_no = $request->issued_cheque_no;
        $data->balance_as_at = $request->balance_as_at;
        $data->name_of_authorizing_individual = $request->name_of_authorizing_individual;
        $data->funds_out = $request->funds_out;
        $data->expense_category_id = $request->expense_category_id;
        $data->school_id = $request->school_id;
        $data->term_id = $term_id[0]->id;
        $data->session_id = $session_id[0]->id;
        $final = $data->save();

        if ($final) {
            return response([
                'success' => true,
                'message' => "Expense Added Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }

        // return (new ExpenseResource($expense))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(Expense $expense)
    {
        abort_if(Gate::denies('expense_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new ExpenseResource($expense->load(['expense_category', 'school']));
    }

    public function update(UpdateExpenseRequest $request, Expense $expense)
    {
        // $expense->update($request->all());

        $data = Expense::find($expense->id);
        $data->entry_date = $request->entry_date;
        $data->amount = $request->amount;
        $data->description = $request->description;
        $data->beneficiary = $request->beneficiary;
        $data->issued_cheque_no = $request->issued_cheque_no;
        $data->balance_as_at = $request->balance_as_at;
        $data->name_of_authorizing_individual = $request->name_of_authorizing_individual;
        $data->funds_out = $request->funds_out;
        $data->expense_category_id = $request->expense_category_id;
        $final = $data->update();

        if ($final) {
            return response([
                'success' => true,
                'message' => "Expense Updated Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }

        // return (new ExpenseResource($expense))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Expense $expense)
    {
        abort_if(Gate::denies('expense_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $expense->delete();

        if ($expense) {
            return response([
                'success' => true,
                'message' => "Expense Deleted Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }

        // return response(null, Response::HTTP_NO_CONTENT);
    }
}
