<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreParentGuardianregisterRequest;
use App\Http\Requests\UpdateParentGuardianregisterRequest;
use App\Http\Resources\Admin\ParentGuardianregisterResource;
use App\Parents;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ParentsApiController extends Controller
{
    public function index()
    {
        // abort_if(Gate::denies('parent_guardianregister_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        // return new ParentGuardianregisterResource(Parents::with(['schools'])->get());

        $data = Parents::with(["incomeStatus", "school", "gender"])->get();
        return response(
            json_decode($data),
        200);
    }

    public function store(Request $request)
    {
        $data = new Parents();
        $data->first_name = $request->first_name;
        $data->middle_name = $request->middle_name;
        $data->last_name = $request->last_name;
        $data->email = $request->email;
        $data->gender_id = $request->gender_id;
        $data->date_of_birth = $request->date_of_birth;
        $data->phone_number = $request->phone_number;
        $data->address = $request->address;
        $data->profession = $request->profession;
        $data->income = $request->income;
        $final = $data->save();

        if ($final) {
            return response([
                'success' => true,
                'message' => "Parent Added Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }
    }

    public function show(Parents $parent)
    {
        // abort_if(Gate::denies('parent_guardianregister_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new ParentGuardianregisterResource($parent->load(['school']));
    }

    public function update(Request $request, $parents)
    {   
        // $parentGuardianregister->update($request->all());
        // $parentGuardianregister->schools()->sync($request->input('schools', []));

        // return (new ParentGuardianregisterResource($parentGuardianregister))
        //     ->response()
        //     ->setStatusCode(Response::HTTP_ACCEPTED);

        $data = Parents::find($parents);
        $data->first_name = $request->first_name;
        $data->middle_name = $request->middle_name;
        $data->last_name = $request->last_name;
        $data->email = $request->email;
        $data->gender_id = $request->gender_id;
        $data->date_of_birth = $request->date_of_birth;
        $data->phone_number = $request->phone_number;
        $data->address = $request->address;
        $data->profession = $request->profession;
        $data->income = $request->income;
        $final = $data->update();

        if ($final) {
            return response([
                'success' => true,
                'message' => "Parent Updated Successfully",
            ], 200);
        } else {
            return response([
                'success' => false,
                'message' => "Operation Failed, Server Error!",
            ], 200);
        }
    }

    public function destroy($parents)
    {
        // abort_if(Gate::denies('parent_guardianregister_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $data = Parents::find($parents);
        $data->delete();
        return response([
            'success' => true,
            'message' => $data,
        ], 200);

        // $parents->delete();

        // if ($parents) {
        //     return response([
        //         'success' => true,
        //         'message' => "Parent Data Deleted Successfullyy",
        //     ], 200);
        // } else {
        //     return response([
        //         'success' => false,
        //         'message' => "Operation Failed, Server Error!",
        //     ], 200);
        // }

        // return response(null, Response::HTTP_NO_CONTENT);
    }
}
