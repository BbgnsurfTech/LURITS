<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTeacherRequest;
use App\Http\Requests\UpdateTeacherRequest;
use App\Http\Resources\Admin\TeacherResource;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Traits\CsvImportTrait;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use Spatie\MediaLibrary\Models\Media;
use App\Http\Requests\MassDestroyStaffRequest;
use App\Http\Requests\StoreStaffRequest;
use App\Http\Requests\UpdateStaffRequest;
use Validator;
use Storage;
use App\SchoolAtlas;
use App\Staff;
use App\Term;
use App\AtlasLink;
use App\Session;
use App\DsPresentStatus;
use App\DsTeachingTypePartTime;
use App\DsSalarySource;
use App\DsGender;
use App\DsAcademicQualification;
use App\DsTeachingType;
use App\DsTypeStaff;
use App\DsSector;
use App\DsMaritalStatus;
use App\DsTeachingQualification;
use App\DsSeminarWorkshop;
use App\DsDisability;
use App\DsSubject;
use App\School;
use App\Atlas;
use App\User;
use Illuminate\Support\Collection;
use Yajra\DataTables\Facades\DataTables;
use Auth;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Haruncpi\LaravelIdGenerator\IdGenerator;

class StaffsApiController extends Controller
{
    public function index(Request $request)
    {
        // abort_if(Gate::denies('staff_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        // return new TeacherResource(Teacher::with(['school'])->get());

        $data = Staff::where("school_id", Auth::User()->school_id)->get();
        return response($data);
    }

    public function store(Request $request)
    {
        //dd($request->all());
        if (Auth::User()->is_headTeacher) {
            $staff_school = Auth::User()->school_id;
        } else {
            $request->validate([
                'school' => "required",
            ]);
            $staff_school = $request->school;
        }

        // if ($request->staff_picture !== null) {
        //     $name = $request->first_name. ' ' .$request->last_name;
        //     $image = 'storage/files/'.$request->input('staff_picture');
        //     $file = Storage::url($image);
        //     $url = config("app.url");
        //     $b = asset($url.'/'.$image);
        //     // dd($image);

        //     $imagee = base64_encode(file_get_contents($image));
        //     // dd($imagee);
        // }

        $term_id = Term::where('active_status', 1)->pluck('id')->first();
        $session_id = Session::where('active_status', 1)->pluck('id')->first();
        
        // if ($request->academic_qualification !== "1") {
        //     $request->validate([
        //         'teaching_qualification' => "required",
        //         'area_of_specialization' => "required",
        //         'subject_of_qualification' => "required",
        //         'subject_taught' => "required",
        //         'seminar_workshop' => "required",
        //         'rank' => "required",
        //     ]);
        // }


        // $aa = Staff::where('school_id', $staff_school)->where('type_staff_id', $request->type_of_staff)->get();
        // foreach ($aa as $staff) {
        //     if ($staff->type_staff_id == 1 || $staff->type_staff_id == 2 || $staff->type_staff_id == 7) {
        //             session()->flash('error', 'The selected type of staff already exist for this school.');
        //             return redirect()->back();
        //         }    
        // }

        // if ($request->lga_origin == 0) {
        //     session()->flash('error', 'Operation Failed. You didn\'t select LGA of Origin');
        //     return redirect()->back();
        // }

        // if ($staff_school == 0) {
        //     session()->flash('error', 'Operation Failed. You didn\'t select School');
        //     return redirect()->back();
        // }

        // if ($request->teaching_type == 2 && $request->teaching_type_part_time == null) {
        //     session()->flash('error', 'Operation Failed. You selected PART TIME for staff teaching type, but didn\'t specify the staff\'s teaching type');
        //     return redirect()->back();
        // }

        $r = School::find($staff_school)->lga->code_atlas_entity;
        $rr = Atlas::where('code_atlas_entity', $r)->pluck('short_code')->first();
        $rrr = AtlasLink::where('code_atlas_entity', $r)->get();
        $s = Staff::count() +1;
        $t = $rr.'-';
        $u = str_pad($t, 10, '0', STR_PAD_RIGHT).$s;
        // dd($u);
        // return ($u);

        if ($request->type_of_staff == 1 || $request->type_of_staff == 2 || $request->type_of_staff == 3 || $request->type_of_staff == 4 || $request->type_of_staff == 5) {
            $role = 5;
        } elseif ($request->type_of_staff == 6 || $request->type_of_staff == 7) {
            $role = 6;
        } else {
            $role = null;
        }
        //dd($role);
        DB::beginTransaction();
        try {
            
            // if ($request->staff_picture !== null) {
            //     // Start Api Create 

            //     $curl = curl_init();

            //     curl_setopt_array($curl, array(
            //         CURLOPT_URL => "https://api.luxand.cloud/subject",
            //         CURLOPT_RETURNTRANSFER => true,
            //         CURLOPT_ENCODING => "",
            //         CURLOPT_MAXREDIRS => 10,
            //         CURLOPT_TIMEOUT => 30,
            //         CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            //         CURLOPT_CUSTOMREQUEST => "POST",
            //         CURLOPT_POSTFIELDS => [ "name" => $name], 
            //         CURLOPT_HTTPHEADER => array(
            //             "token: 631dc0a781be4335997fb893b1d3de55"
            //         ),
            //     ));

            //     $response = curl_exec($curl);
            //     $err = curl_error($curl);

            //     curl_close($curl);

            //     if ($err) {
            //         session()->flash('error', 'Something went wrong while registering user api ID');
            //         return redirect()->back();
            //     } else {
            //         $data = json_decode($response);
            //         $api_id = $data->id;
            //     }

            //     // End Api Create
                
            //     // Start Api Face

            //     $curl = curl_init();
            //     $link = "https://api.luxand.cloud/subject/".$api_id;
            //     curl_setopt_array($curl, array(
            //         CURLOPT_URL => $link,
            //         CURLOPT_RETURNTRANSFER => true,
            //         CURLOPT_ENCODING => "",
            //         CURLOPT_MAXREDIRS => 10,
            //         CURLOPT_TIMEOUT => 30,
            //         CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            //         CURLOPT_CUSTOMREQUEST => "POST",
            //         //CURLOPT_POSTFIELDS => [ "store" => "1", "photo" => curl_file_create($b)], 
            //         // or use URL
            //         CURLOPT_POSTFIELDS => [ "photo" => $imagee ], 
            //         CURLOPT_HTTPHEADER => array(
            //             "token: 631dc0a781be4335997fb893b1d3de55"
            //         ),
            //     ));

            //     $response = curl_exec($curl);
            //     $errr = curl_error($curl);

            //     curl_close($curl);

            //     if ($errr) {
            //         dd($errr);
            //         session()->flash('error', 'Something went wrong while registering user api FACE');
            //         return redirect()->back();
            //     } else {
            //         $res = json_decode($response);
            //     }

            //     // End Api Face
            // }
            $allData = $request->all();

            foreach ($allData as $staffData) {
                $data_id = Staff::where('school_id', $staff_school)->max('id') + 1;
                // dd($data_id);
                if ($data_id == 1) {
                    $model_id = str_pad($staff_school, 15, "0", STR_PAD_RIGHT).$data_id;
                } else {
                    $model_id = $data_id;
                }

                if ($staffData['id'] == '' || $staffData['id'] == null) {
                    $user = new User();
                    $user->name = $staffData['first_name']. ' ' .$staffData['middle_name']. ' ' .$staffData['last_name'];
                    if ($staffData['email'] !== null || $staffData['email'] !== '') {
                        $user->email = $staffData['email'];
                    } else {
                        $user->username = 'custom_username';
                    }
                    $user->password = Hash::make(12345678);
                    $user->school_id = $staff_school;
                    $user->save();
                    $user->toArray();
                    if ($role !== null) {
                        $user->roles()->sync($role);
                    }

                    $data = new Staff();

                } else {
                    $data = Staff::find($staffData['id']);
                }
                
                
                // if ($request->staff_picture !== null) {
                //     $data->api_id = $api_id;
                // }
                if ($staffData['id'] == '' || $staffData['id'] == null) {
                    $data->id = $model_id;
                    $data->staff_id = $u;
                    $data->user_id = $user->id;
                }
                
                $data->first_name = $staffData['first_name'];
                $data->middle_name = $staffData['middle_name'];
                $data->last_name = $staffData['last_name'];
                $data->email = $staffData['email'];
                $data->address = $staffData['address'];
                $data->phone_number = $staffData['phone_number'];
                $data->date_of_birth = $staffData['date_of_birth'];
                $data->state_of_origin_id = $staffData['state_of_origin_id'];
                $data->lga_of_origin_id = $staffData['lga_of_origin_id'];
                $data->marital_status_id = $staffData['marital_status_id'];
                $data->disability_id = $staffData['disability_id'];
                $data->grade_step = $staffData['grade_step'];
                $data->step = $staffData['step'];
                $data->gender_id = $staffData['gender_id'];
                $data->type_staff_id = $staffData['type_staff_id'];
                $data->other_qualification = $staffData['other_qualification'];
                $data->other_salary_source = $staffData['other_salary_source'];
                $data->present_status_id = $staffData['present_status_id'];
                $data->academic_qualification_id = $staffData['academic_qualification_id'];
                $data->teaching_type_id = $staffData['teaching_type_id'];
                $data->salary_source_id = $staffData['salary_source_id'];
                $data->year_first_appointment = $staffData['year_first_appointment'];
                $data->year_present_appointment = $staffData['year_present_appointment'];
                $data->year_posting_to_school = $staffData['year_posting_to_school'];
                if ($staffData['teaching_type_id'] == 2){
                    $data->teaching_type_part_time = $staffData['teaching_type_part_time'];
                }
                $data->term_id = $term_id;
                $data->session_id = $session_id;
                $data->school_id = $staff_school;
                if ($staffData['academic_qualification_id'] !== "1") {
                    $data->rank_id = $staffData['rank_id'];
                    $data->teaching_qualification_id = $staffData['teaching_qualification_id'];
                    $data->area_of_specialization_id = $staffData['area_of_specialization_id'];
                    $data->subject_of_qualification_id = $staffData['subject_of_qualification_id'];
                    $data->main_subject_taught_id = $staffData['main_subject_taught_id'];
                    $data->seminar_workshop_id = $staffData['seminar_workshop_id'];
                    $data->other_area_of_specialization = $staffData['other_area_of_specialization'];
                    $data->other_subject_of_qualification = $staffData['other_subject_of_qualification'];
                    $data->other_main_subject_taught = $staffData['other_main_subject_taught'];
                }
                //dd($data);
                if ($staffData['id'] == '' || $staffData['id'] == null) {
                    $results = $data->save();
                } else {
                    $results = $data->update();
                }
                

            }

            

            // if ($request->input('staff_picture', false)) {
            //     $data->addMedia(storage_path('app/public/files/' . $request->input('staff_picture')))->toMediaCollection('staff_picture');
            // }

            // foreach ($request->input('staff_document', []) as $file) {
            //     $data->addMedia(storage_path('app/public/files/' . $file))->toMediaCollection('staff_document');
            // }

            // if ($media = $request->input('ck-media', false)) {
            //     Media::whereIn('id', $media)->update(['model_id' => $data->id]);
            // }

            

            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
            return response($e);
        }

        if ($results) {
            $message = Staff::where('school_id', $staff_school)->get();
            return response($message);
        }

        
    }

    public function show(Teacher $teacher)
    {
        abort_if(Gate::denies('staff_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new TeacherResource($teacher->load(['school']));
    }

    public function update(UpdateTeacherRequest $request, Teacher $teacher)
    {
        $teacher->update($request->all());

        return (new TeacherResource($teacher))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Staff $staff)
    {
        abort_if(Gate::denies('staff_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $staff->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
