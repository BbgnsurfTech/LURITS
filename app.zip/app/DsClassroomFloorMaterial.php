<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsClassroomFloorMaterial extends Model
{
    //
}
