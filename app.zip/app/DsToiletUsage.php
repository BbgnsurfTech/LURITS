<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsToiletUsage extends Model
{
    protected $table = 'ds_toilet_usage';
}
