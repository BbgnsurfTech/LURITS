<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsTypeStaffSector extends Model
{
    public $table = 'ds_type_staff_sectors';
}
