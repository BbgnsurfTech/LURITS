<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsSchoolType extends Model
{
    //
}
