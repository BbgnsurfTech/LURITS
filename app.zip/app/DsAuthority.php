<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsAuthority extends Model
{
    //
}
