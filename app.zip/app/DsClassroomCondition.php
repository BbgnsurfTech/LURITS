<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsClassroomCondition extends Model
{
    //
}
