<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsFlow extends Model
{
    public $table = 'ds_flow';
}
