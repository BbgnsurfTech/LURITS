<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LessonAttendace extends Model
{
    //
}
