<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsTeachingType extends Model
{
    public $table = 'ds_teaching_type';
}
