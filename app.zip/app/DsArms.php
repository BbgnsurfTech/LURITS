<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsArms extends Model
{
    public $table = 'ds_arms';
}
