<?php

namespace App\Models\Students;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //
}
