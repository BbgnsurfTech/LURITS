<?php

namespace App\Models\Staff;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    //
}
