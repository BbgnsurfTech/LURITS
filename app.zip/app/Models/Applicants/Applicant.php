<?php

namespace App\Models\Applicants;

use Illuminate\Database\Eloquent\Model;

class Applicant extends Model
{
    //
}
