<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsEconomicStatus extends Model
{
    public $table = 'ds_economic_statuses';
}
