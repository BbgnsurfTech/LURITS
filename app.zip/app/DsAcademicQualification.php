<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsAcademicQualification extends Model
{
    public $table = 'ds_academic_qualification';
}
