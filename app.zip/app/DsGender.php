<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsGender extends Model
{
    public $table = 'ds_gender';
}
