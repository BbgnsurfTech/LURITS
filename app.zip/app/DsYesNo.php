<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsYesNo extends Model
{
    public $table = 'ds_yes_no';
}
