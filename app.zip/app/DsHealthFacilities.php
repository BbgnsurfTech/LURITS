<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsHealthFacilities extends Model
{
    //
}
