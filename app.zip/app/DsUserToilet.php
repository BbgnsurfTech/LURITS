<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DsUserToilet extends Model
{
    protected $table = 'ds_user_toilet';
}
